
export interface Periodo{
    id: number;
    nombre: string;
    semestre: number;
    fechaInicio: string;
    fechaFin: string;
    estado: number;
    anio: number;
}