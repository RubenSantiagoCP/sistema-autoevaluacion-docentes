import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PrincipalComponent } from './principal/principal.component';
import { GesDocenteComponent } from './ges-docente/ges-docente.component';
import { AeDocenteComponent } from './ae-docente/ae-docente.component';
//import { ModuloAutoevComponent } from './modulo-autoev/ModuloAutoevComponent';

const routes: Routes = [
  {path: '', component: PrincipalComponent},
  //{path: 'modulo/periodo/docente', component: ModuloAutoevComponent},
  {path:'ges-docente', component: GesDocenteComponent},
  {path: 'editar/:id', component: AeDocenteComponent},
  {path: 'agregar-docente', component: AeDocenteComponent},
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CoordinadorRoutingModule { }
