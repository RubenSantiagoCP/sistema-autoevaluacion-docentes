import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GestLaboresComponent } from './gest-labores.component';

describe('GestLaboresComponent', () => {
  let component: GestLaboresComponent;
  let fixture: ComponentFixture<GestLaboresComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [GestLaboresComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(GestLaboresComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
