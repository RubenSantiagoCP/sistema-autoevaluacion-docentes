import { Component } from '@angular/core';
import { Docente } from '../../../interfaces/docente';

@Component({
  selector: 'app-gest-labores',
  templateUrl: './gest-labores.component.html',
  styleUrl: './gest-labores.component.css'
})
export class GestLaboresComponent {
  objDocente:Docente = {
    id:1,identificacion: 12345, nombre: "Francisco", apellido: "Obando", genero: "M", rol: "Docencia", correo: "fobando@unicauca.edu.co",estado: 1, estudio: "Maestria"
  }

  
}
