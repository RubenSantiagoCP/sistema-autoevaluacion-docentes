import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CoordinadorRoutingModule } from './coordinador-routing.module';
import { PrincipalComponent } from './principal/principal.component';
import { NavbarComponent } from './navbar/navbar.component';
import { GestLaboresComponent } from './gest-labores/gest-labores.component';
import { GesDocenteComponent } from './ges-docente/ges-docente.component';
import { AeDocenteComponent } from './ae-docente/ae-docente.component';


@NgModule({
  declarations: [
    PrincipalComponent,
    NavbarComponent,
    GestLaboresComponent,
    GesDocenteComponent,
    AeDocenteComponent
  ],
  imports: [
    CommonModule,
    CoordinadorRoutingModule
  ],
  exports:[
    
  ]
})
export class CoordinadorModule { }
