export interface Periodo{
    //id: number;
    nombre: string;
    semestre: number;
    anio:number;
    fechaInicio: string;
    fechaFin: string;
    //estado: number;
}