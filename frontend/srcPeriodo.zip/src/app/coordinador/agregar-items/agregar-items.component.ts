import { Component } from '@angular/core';

@Component({
  selector: 'app-agregar-items',
  templateUrl: './agregar-items.component.html',
  styleUrl: './agregar-items.component.css'
})
export class AgregarItemsComponent {
  lstItems = [
    {name: 'Bases de datos', estado: 'En ejecucion', tipo: 'Docencia', horas: '64', Descripcion: 'Ingenieria de Sistemas Obligatoria 2023', FechaInicio: '14/08/2023', fechaFin: '30/11/2023', Resultados: '', Evaluacion: 0.0, acto: 'Si aplica' }
  ]
}
